package javaapplication8;      
       
import java.util.Scanner;
 
public class Punto8 {

    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
        System.out.print("Ingresa el número de filas para la pirámide: ");
        int num = scanner.nextInt();
        int a = 0;
        
        for (int i = num; i >= a; i--) {

            for (int b = a; b <= num - i; b++) {
                System.out.print(" ");
            }
            

            for (int c = a; c <= 2 * i - c; c++) {
                System.out.print("*");
            }
            
           
            System.out.println();
        }
    }
}
