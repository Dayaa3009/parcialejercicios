public class Punto6 {

    public static void main(String[] args) {
        int variablenum1, variablenum2, variablerdo;
        
                Scanner leer= new Scanner(System.in);
                
                
        System.out.println("Escriba ombre de la variable");
       variablenum1 = leer.nextInt();
       
        System.out.println("Escriba ombre de la variable");
       variablenum1 = leer.nextInt();

       
        System.out.println("Escriba ombre de la variable");
       variablenum1 = leer.nextInt();

        
        
    }
}
